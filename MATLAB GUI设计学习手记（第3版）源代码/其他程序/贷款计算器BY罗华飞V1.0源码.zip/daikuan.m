function varargout = daikuan(varargin)
% DAIKUAN MATLAB code for daikuan.fig
%      DAIKUAN, by itself, creates a new DAIKUAN or raises the existing
%      singleton*.
%
%      H = DAIKUAN returns the handle to a new DAIKUAN or the handle to
%      the existing singleton*.
%
%      DAIKUAN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DAIKUAN.M with the given input arguments.
%
%      DAIKUAN('Property','Value',...) creates a new DAIKUAN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before daikuan_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to daikuan_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help daikuan

% Last Modified by GUIDE v2.5 04-Mar-2013 16:12:50

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @daikuan_OpeningFcn, ...
                   'gui_OutputFcn',  @daikuan_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before daikuan is made visible.
function daikuan_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to daikuan (see VARARGIN)

% Choose default command line output for daikuan
handles.output = hObject;

b = cell(31,1);
b{1} = '����(6��)';
for i=1:30
    teams = 12*i;
    b{i+1} = [num2str(i),'��(', num2str(teams), '��)'];
end
set(handles.pop_nYear,'string',b,'value',16);

global i_year xi n_all
i_year = [6.14, 6.4, 6.6, 6.8, 7.05, 6.8, 6.55];%��׼����
xi = [1,0.7,0.75,0.8,0.85,0.9,1.1];
n_all = [6;12*[1:30]'];


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes daikuan wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = daikuan_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function pop_r_Callback(hObject, eventdata, handles)
global i_year xi
r = i_year(get(handles.pop_r,'value'))*xi(get(handles.pop_xi,'value'));
set(handles.edit_i,'string',num2str(r,'%3.2f'));

function pop_r_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_c_Callback(hObject, eventdata, handles)


function edit_c_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function pop_nYear_Callback(hObject, eventdata, handles)


function pop_nYear_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function popupmenu3_Callback(hObject, eventdata, handles)


function popupmenu3_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_i_Callback(hObject, eventdata, handles)


function edit_i_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function pushbutton1_Callback(hObject, eventdata, handles)
%P-����/��ֵ n-�������� r-������ i-��Ϣ������С���� A-�ȶ��ֽ����� F-��ֵ
%Pn-ÿ���������� Pi-�ۼ��ѻ����� I-��Ϣ In-����������Ϣ

global i_year xi n_all
P = str2double(get(handles.edit_c,'string'))*10000;%����capital,��ֵ
n = n_all(get(handles.pop_nYear,'value'));%����
r = str2double(get(handles.edit_i,'string'))/100;%������
i = r/12;%����Ч����
datas = cell(n,5);
if(get(handles.radiobutton1,'value'))%�ȶϢ;�ȶ��ֽ��������㷽��
    %F = P*(1+i)^n;%��ֵ
    %��ʽF=A/i*((1+i)^n-1)
    %A = F*i/((1+i)^n-1);%ÿ�»����ܶ�
    A = P*i/(1-(1+i)^(-n));%ÿ�»����ܶ�
    I = A*n-P;
    set(handles.edit_IAll,'string',num2str(I,'%10.2f'));
    set(handles.edit_PI,'string',num2str(A*n,'%10.2f'));
    
    Pn = zeros(n,1);%ÿ������������
    Bn = zeros(n+1,1);%ÿ������Ƿ����
    In = zeros(n,1);
    Bn(1) = P;
    for m=1:n
        In(m) = Bn(m)*i;%��m���»�����Ϣ
        Pn(m) = A - In(m);%��m���»��ı���
        Bn(m+1) = Bn(m) - Pn(m);%���±���    
    end
    
    for m=1:n
        datas{m,1} = sprintf('%g',m);
        datas{m,2} = sprintf('%10.2f',A);
        datas{m,3} = sprintf('%10.2f',In(m));
        datas{m,4} = sprintf('%10.2f',Pn(m)); 
        datas{m,5} = sprintf('%10.2f',Bn(m+1)); 
    end
else
    Pn = P/n;%ÿ����������    
    Pi = zeros(n+1,1); %ÿ���ۼ��ѻ�����
    In = zeros(n,1);%ÿ��������Ϣ
    for index=1:n
        In(index) = (P-Pi(index))*i;%����������Ϣ
        Pi(index+1) = Pn*index;
    end
    I = sum(In);
    set(handles.edit_IAll,'string',num2str(I,'%10.2f'));
    set(handles.edit_PI,'string',num2str(I+P,'%10.2f'));

    for m=1:n
        datas{m,1} = sprintf('%g',m);
        datas{m,2} = sprintf('%10.2f',Pn+In(m));
        datas{m,3} = sprintf('%10.2f',In(m));
        datas{m,4} = sprintf('%10.2f',Pn); 
        datas{m,5} = sprintf('%10.2f',P-Pi(m+1)); 
    end    
end
set(handles.tab_data,'data',datas);


function pushbutton2_Callback(hObject, eventdata, handles)


function edit_IAll_Callback(hObject, eventdata, handles)


function edit_IAll_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_PI_Callback(hObject, eventdata, handles)


function edit_PI_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function pop_xi_Callback(hObject, eventdata, handles)
pop_r_Callback(hObject, eventdata, handles);

function pop_xi_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
